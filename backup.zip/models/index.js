const userModel = require('./user-model')
const assignmentModel = require('./assignment-model')
const userAssignmentModel = require('./user-assignment-model')

module.exports = {
   userModel,
   assignmentModel,
   userAssignmentModel
}
