#!/bin/bash

# Update the package manager and upgrade installed packages
sudo apt-get update
sudo apt-get upgrade -y