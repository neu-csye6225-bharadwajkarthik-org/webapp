#!/bin/bash

# Install 'unzip' with sudo
sudo apt-get install -y unzip

# unzip artifact to 'forkedWebappRepo' folder in /opt
sudo unzip -d /opt ~/forkedWebappRepo.zip

ls -al "/opt/forkedWebappRepo"
# move the csv file to /opt folder
sudo cp "/opt/forkedWebappRepo/user.csv" /opt